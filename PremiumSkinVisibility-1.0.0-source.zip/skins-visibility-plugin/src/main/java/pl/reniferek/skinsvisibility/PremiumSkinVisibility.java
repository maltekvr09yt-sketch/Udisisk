package pl.reniferek.skinsvisibility;

import net.skinsrestorer.api.SkinsRestorer;
import net.skinsrestorer.api.SkinsRestorerProvider;
import net.skinsrestorer.api.property.SkinProperty;
import net.skinsrestorer.api.storage.SkinStorage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Optional;
import java.util.UUID;

public final class PremiumSkinVisibility extends JavaPlugin implements Listener {
    private SkinsRestorer api;
    private boolean premiumSeeNoPremium = true;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        premiumSeeNoPremium = getConfig().getBoolean("premium-see-no-premium", true);

        try {
            api = SkinsRestorerProvider.get();
        } catch (Throwable t) {
            getLogger().severe("Nie znaleziono SkinsRestorer API. Zainstaluj SkinsRestorer.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        Bukkit.getPluginManager().registerEvents(this, this);

        // Po dołączeniu daj SkinsRestorer chwilę na załadowanie skina,
        // następnie odśwież widok graczy.
        Bukkit.getScheduler().runTaskTimer(this, this::refreshAll, 20L, 40L);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, this::refreshAll, 30L);
    }

    private void refreshAll() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            for (Player target : Bukkit.getOnlinePlayers()) {
                if (viewer.equals(target)) continue;
                if (!shouldShowRealSkin(viewer, target)) {
                    applyTargetSkinToViewer(viewer, target);
                }
            }
        }
    }

    private boolean shouldShowRealSkin(Player viewer, Player target) {
        boolean viewerPremium = isPremium(viewer);
        boolean targetPremium = isPremium(target);

        if (targetPremium) {
            // Premium widzi Premium. No-Premium też nie dostaje prawdziwego
            // skina Premium.
            return viewerPremium;
        }

        // Skina No-Premium może widzieć każdy.
        return true;
    }

    private boolean isPremium(Player player) {
        // Najpewniejszy sygnał dla serwera: online-mode.
        // Dodatkowo można wymusić status permissionem.
        if (player.hasPermission("psv.premium")) return true;
        if (player.hasPermission("psv.nopremium")) return false;
        return Bukkit.getOnlineMode();
    }

    private void applyTargetSkinToViewer(Player viewer, Player target) {
        try {
            SkinStorage storage = api.getSkinStorage();
            Optional<SkinProperty> prop = storage.getSkinForPlayer(
                    target.getUniqueId(), target.getName()
            );

            if (prop.isEmpty()) return;

            // SkinsRestorer API nie oferuje publicznego, stabilnego API do
            // per-viewer skinów. Wersje SR mogą zmieniać API, dlatego ten
            // plugin przechowuje logikę grupowania, a właściwe per-viewer
            // pakiety powinny być obsługiwane przez SR/ProtocolLib.
            //
            // Celowo nie wykonujemy tutaj globalnego setSkin(), bo zmieniłoby
            // to skin targetowi dla wszystkich graczy.
        } catch (Throwable ignored) {
        }
    }
}
